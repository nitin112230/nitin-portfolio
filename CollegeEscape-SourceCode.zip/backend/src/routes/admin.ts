import { Router } from "express";
import { db } from "@workspace/db";
import { tripsTable, bookingsTable, usersTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { z } from "zod";

const router = Router();

const ADMIN_KEY = process.env.ADMIN_KEY ?? "";

function requireAdmin(req: any, res: any): boolean {
  const key = req.headers["x-admin-key"];
  if (!key || key !== ADMIN_KEY) {
    res.status(403).json({ error: "Forbidden" });
    return false;
  }
  return true;
}

router.get("/admin/overview", async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const trips = await db.select().from(tripsTable);
  const users = await db.select().from(usersTable);
  const bookings = await db.select().from(bookingsTable);
  const confirmed = bookings.filter(b => b.status === "confirmed");

  return res.json({
    totalTrips: trips.length,
    totalUsers: users.length,
    totalBookings: bookings.length,
    confirmedBookings: confirmed.length,
    totalSeatsBooked: bookings.reduce((acc, b) => acc + b.numberOfPeople, 0),
  });
});

router.get("/admin/trips", async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const trips = await db.select().from(tripsTable).orderBy(desc(tripsTable.createdAt));
  return res.json(trips.map(t => ({
    ...t,
    price: parseFloat(t.price as unknown as string),
    createdAt: t.createdAt.toISOString(),
  })));
});

router.put("/admin/trips/:id", async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  const schema = z.object({
    title: z.string().optional(),
    destination: z.string().optional(),
    description: z.string().optional(),
    price: z.number().optional(),
    duration: z.string().optional(),
    departureDate: z.string().optional(),
    returnDate: z.string().optional(),
    totalSeats: z.number().optional(),
    availableSeats: z.number().optional(),
    status: z.string().optional(),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  const updates: any = {};
  const d = parsed.data;
  if (d.title !== undefined) updates.title = d.title;
  if (d.destination !== undefined) updates.destination = d.destination;
  if (d.description !== undefined) updates.description = d.description;
  if (d.price !== undefined) updates.price = d.price.toFixed(2);
  if (d.duration !== undefined) updates.duration = d.duration;
  if (d.departureDate !== undefined) updates.departureDate = d.departureDate;
  if (d.returnDate !== undefined) updates.returnDate = d.returnDate;
  if (d.totalSeats !== undefined) updates.totalSeats = d.totalSeats;
  if (d.availableSeats !== undefined) updates.availableSeats = d.availableSeats;
  if (d.status !== undefined) updates.status = d.status;

  const [updated] = await db.update(tripsTable).set(updates).where(eq(tripsTable.id, id)).returning();
  if (!updated) return res.status(404).json({ error: "Trip not found" });

  return res.json({ ...updated, price: parseFloat(updated.price as unknown as string), createdAt: updated.createdAt.toISOString() });
});

router.get("/admin/bookings", async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const bookings = await db.select().from(bookingsTable).orderBy(desc(bookingsTable.createdAt));
  const result = await Promise.all(bookings.map(async b => {
    const [trip] = await db.select({ title: tripsTable.title, destination: tripsTable.destination }).from(tripsTable).where(eq(tripsTable.id, b.tripId)).limit(1);
    const [user] = await db.select({ name: usersTable.name, email: usersTable.email, college: usersTable.college, phone: usersTable.phone }).from(usersTable).where(eq(usersTable.id, b.userId)).limit(1);
    return {
      id: b.id,
      tripTitle: trip?.title ?? "—",
      tripDestination: trip?.destination ?? "—",
      userName: user?.name ?? "—",
      userEmail: user?.email ?? "—",
      userCollege: user?.college ?? "—",
      userPhone: user?.phone ?? "—",
      numberOfPeople: b.numberOfPeople,
      totalAmount: parseFloat(b.totalAmount as unknown as string),
      status: b.status,
      specialRequests: b.specialRequests,
      createdAt: b.createdAt.toISOString(),
    };
  }));

  return res.json(result);
});

router.get("/admin/users", async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const users = await db.select({
    id: usersTable.id,
    name: usersTable.name,
    email: usersTable.email,
    college: usersTable.college,
    phone: usersTable.phone,
    createdAt: usersTable.createdAt,
  }).from(usersTable).orderBy(desc(usersTable.createdAt));

  const withCounts = await Promise.all(users.map(async u => {
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(bookingsTable).where(eq(bookingsTable.userId, u.id));
    return { ...u, bookingCount: Number(count), createdAt: u.createdAt.toISOString() };
  }));

  return res.json(withCounts);
});

export default router;
