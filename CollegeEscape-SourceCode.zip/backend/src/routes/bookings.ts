import { Router } from "express";
import { db } from "@workspace/db";
import { bookingsTable, tripsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { parseToken } from "./auth";
import { z } from "zod";

const router = Router();

function requireAuth(req: any, res: any): number | null {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Not authenticated" });
    return null;
  }
  const userId = parseToken(authHeader.slice(7));
  if (!userId) {
    res.status(401).json({ error: "Invalid token" });
    return null;
  }
  return userId;
}

function formatTrip(trip: typeof tripsTable.$inferSelect) {
  return {
    id: trip.id,
    title: trip.title,
    destination: trip.destination,
    description: trip.description,
    imageUrl: trip.imageUrl,
    price: parseFloat(trip.price as unknown as string),
    duration: trip.duration,
    departureDate: trip.departureDate,
    returnDate: trip.returnDate,
    totalSeats: trip.totalSeats,
    availableSeats: trip.availableSeats,
    highlights: trip.highlights,
    partyPlaces: trip.partyPlaces,
    includes: trip.includes,
    status: trip.status,
    createdAt: trip.createdAt.toISOString(),
  };
}

const bookingSchema = z.object({
  tripId: z.number().int().positive(),
  numberOfPeople: z.number().int().min(1).max(20),
  specialRequests: z.string().optional(),
});

router.get("/bookings", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const bookings = await db.select().from(bookingsTable).where(eq(bookingsTable.userId, userId));
  const result = await Promise.all(
    bookings.map(async (b) => {
      const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, b.tripId)).limit(1);
      return {
        id: b.id,
        tripId: b.tripId,
        userId: b.userId,
        numberOfPeople: b.numberOfPeople,
        totalAmount: parseFloat(b.totalAmount as unknown as string),
        status: b.status,
        specialRequests: b.specialRequests,
        trip: trip ? formatTrip(trip) : null,
        createdAt: b.createdAt.toISOString(),
      };
    })
  );

  return res.json(result);
});

router.post("/bookings", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = bookingSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  const { tripId, numberOfPeople, specialRequests } = parsed.data;

  const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, tripId)).limit(1);
  if (!trip) return res.status(404).json({ error: "Trip not found" });
  if (trip.availableSeats < numberOfPeople) {
    return res.status(400).json({ error: "Not enough seats available" });
  }

  const totalAmount = parseFloat(trip.price as unknown as string) * numberOfPeople;

  const [booking] = await db.insert(bookingsTable).values({
    tripId,
    userId,
    numberOfPeople,
    totalAmount: totalAmount.toFixed(2) as unknown as number,
    status: "pending",
    specialRequests: specialRequests ?? null,
  }).returning();

  return res.status(201).json({
    id: booking.id,
    tripId: booking.tripId,
    userId: booking.userId,
    numberOfPeople: booking.numberOfPeople,
    totalAmount: parseFloat(booking.totalAmount as unknown as string),
    status: booking.status,
    specialRequests: booking.specialRequests,
    trip: formatTrip(trip),
    createdAt: booking.createdAt.toISOString(),
  });
});

router.get("/bookings/:id", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid booking id" });

  const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, id)).limit(1);
  if (!booking || booking.userId !== userId) return res.status(404).json({ error: "Booking not found" });

  const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, booking.tripId)).limit(1);

  return res.json({
    id: booking.id,
    tripId: booking.tripId,
    userId: booking.userId,
    numberOfPeople: booking.numberOfPeople,
    totalAmount: parseFloat(booking.totalAmount as unknown as string),
    status: booking.status,
    specialRequests: booking.specialRequests,
    trip: trip ? formatTrip(trip) : null,
    createdAt: booking.createdAt.toISOString(),
  });
});

export default router;
