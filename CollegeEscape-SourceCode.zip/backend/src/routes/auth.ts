import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { createHash, randomBytes } from "crypto";
import { z } from "zod";

const router = Router();

function hashPassword(password: string): string {
  const salt = "cet_salt_2024";
  return createHash("sha256").update(password + salt).digest("hex");
}

function generateToken(userId: number): string {
  const rand = randomBytes(16).toString("hex");
  return Buffer.from(`${userId}:${rand}:${Date.now()}`).toString("base64");
}

function parseToken(token: string): number | null {
  try {
    const decoded = Buffer.from(token, "base64").toString("utf-8");
    const parts = decoded.split(":");
    const id = parseInt(parts[0]);
    if (isNaN(id)) return null;
    return id;
  } catch {
    return null;
  }
}

const registerSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  password: z.string().min(6),
  college: z.string().min(1),
  phone: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

router.post("/auth/register", async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid input" });
  }
  const { name, email, password, college, phone } = parsed.data;

  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing.length > 0) {
    return res.status(400).json({ error: "Email already registered" });
  }

  const [user] = await db.insert(usersTable).values({
    name,
    email,
    passwordHash: hashPassword(password),
    college,
    phone: phone ?? null,
  }).returning();

  const token = generateToken(user.id);
  return res.status(201).json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      college: user.college,
      phone: user.phone,
      createdAt: user.createdAt.toISOString(),
    },
    token,
  });
});

router.post("/auth/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid input" });
  }
  const { email, password } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (!user || user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  const token = generateToken(user.id);
  return res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      college: user.college,
      phone: user.phone,
      createdAt: user.createdAt.toISOString(),
    },
    token,
  });
});

router.post("/auth/logout", (_req, res) => {
  return res.json({ message: "Logged out successfully" });
});

router.get("/auth/me", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Not authenticated" });
  }
  const token = authHeader.slice(7);
  const userId = parseToken(token);
  if (!userId) {
    return res.status(401).json({ error: "Invalid token" });
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  if (!user) {
    return res.status(401).json({ error: "User not found" });
  }

  return res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    college: user.college,
    phone: user.phone,
    createdAt: user.createdAt.toISOString(),
  });
});

export { parseToken };
export default router;
