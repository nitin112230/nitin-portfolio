import { Router } from "express";
import { db } from "@workspace/db";
import { paymentsTable, bookingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { parseToken } from "./auth";
import { randomBytes } from "crypto";
import { z } from "zod";

const router = Router();

function requireAuth(req: any, res: any): number | null {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Not authenticated" });
    return null;
  }
  const userId = parseToken(authHeader.slice(7));
  if (!userId) {
    res.status(401).json({ error: "Invalid token" });
    return null;
  }
  return userId;
}

const paymentSchema = z.object({
  bookingId: z.number().int().positive(),
  method: z.enum(["upi", "card", "netbanking"]),
  upiId: z.string().optional().nullable(),
  cardNumber: z.string().optional().nullable(),
  cardHolder: z.string().optional().nullable(),
  expiry: z.string().optional().nullable(),
  cvv: z.string().optional().nullable(),
});

router.post("/payments/initiate", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = paymentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid payment details" });

  const { bookingId, method } = parsed.data;

  const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, bookingId)).limit(1);
  if (!booking || booking.userId !== userId) return res.status(404).json({ error: "Booking not found" });

  const [payment] = await db.insert(paymentsTable).values({
    bookingId,
    amount: booking.totalAmount,
    method,
    status: "pending",
    transactionId: null,
  }).returning();

  return res.json({
    id: payment.id,
    bookingId: payment.bookingId,
    amount: parseFloat(payment.amount as unknown as string),
    method: payment.method,
    status: payment.status,
    transactionId: payment.transactionId,
    createdAt: payment.createdAt.toISOString(),
  });
});

router.post("/payments/:id/confirm", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid payment id" });

  const [payment] = await db.select().from(paymentsTable).where(eq(paymentsTable.id, id)).limit(1);
  if (!payment) return res.status(404).json({ error: "Payment not found" });

  const transactionId = "TXN" + randomBytes(8).toString("hex").toUpperCase();

  const [updated] = await db.update(paymentsTable)
    .set({ status: "confirmed", transactionId })
    .where(eq(paymentsTable.id, id))
    .returning();

  await db.update(bookingsTable)
    .set({ status: "confirmed" })
    .where(eq(bookingsTable.id, payment.bookingId));

  return res.json({
    id: updated.id,
    bookingId: updated.bookingId,
    amount: parseFloat(updated.amount as unknown as string),
    method: updated.method,
    status: updated.status,
    transactionId: updated.transactionId,
    createdAt: updated.createdAt.toISOString(),
  });
});

export default router;
