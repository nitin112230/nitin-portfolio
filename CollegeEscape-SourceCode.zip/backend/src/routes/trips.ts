import { Router } from "express";
import { db } from "@workspace/db";
import { tripsTable, bookingsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

function formatTrip(trip: typeof tripsTable.$inferSelect) {
  return {
    id: trip.id,
    title: trip.title,
    destination: trip.destination,
    description: trip.description,
    imageUrl: trip.imageUrl,
    price: parseFloat(trip.price as unknown as string),
    duration: trip.duration,
    departureDate: trip.departureDate,
    returnDate: trip.returnDate,
    totalSeats: trip.totalSeats,
    availableSeats: trip.availableSeats,
    highlights: trip.highlights,
    partyPlaces: trip.partyPlaces,
    includes: trip.includes,
    status: trip.status,
    createdAt: trip.createdAt.toISOString(),
  };
}

router.get("/trips/stats", async (_req, res) => {
  const trips = await db.select().from(tripsTable);
  const bookingCount = await db.select({ count: sql<number>`count(*)` }).from(bookingsTable).where(eq(bookingsTable.status, "confirmed"));
  const cities = new Set(trips.map(t => t.destination)).size;

  return res.json({
    totalTrips: trips.length,
    totalStudents: Number(bookingCount[0]?.count ?? 0),
    citiesCovered: cities,
    avgRating: 4.8,
  });
});

router.get("/trips/featured", async (_req, res) => {
  const trips = await db.select().from(tripsTable).where(eq(tripsTable.status, "active")).limit(4);
  return res.json(trips.map(formatTrip));
});

router.get("/trips", async (_req, res) => {
  const trips = await db.select().from(tripsTable).where(eq(tripsTable.status, "active"));
  return res.json(trips.map(formatTrip));
});

router.get("/trips/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid trip id" });

  const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id)).limit(1);
  if (!trip) return res.status(404).json({ error: "Trip not found" });

  return res.json(formatTrip(trip));
});

export default router;
