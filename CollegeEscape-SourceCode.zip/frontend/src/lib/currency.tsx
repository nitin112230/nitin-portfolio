import { createContext, useContext, useState, ReactNode } from "react";

export type CurrencyCode = "INR" | "USD" | "GBP" | "EUR" | "AED" | "AUD" | "SGD" | "CAD";

export const CURRENCIES: { code: CurrencyCode; flag: string; symbol: string; rateFromINR: number }[] = [
  { code: "INR", flag: "🇮🇳", symbol: "₹", rateFromINR: 1 },
  { code: "USD", flag: "🇺🇸", symbol: "$", rateFromINR: 1 / 83 },
  { code: "GBP", flag: "🇬🇧", symbol: "£", rateFromINR: 1 / 105 },
  { code: "EUR", flag: "🇪🇺", symbol: "€", rateFromINR: 1 / 90 },
  { code: "AED", flag: "🇦🇪", symbol: "AED", rateFromINR: 1 / 22.6 },
  { code: "AUD", flag: "🇦🇺", symbol: "A$", rateFromINR: 1 / 54 },
  { code: "SGD", flag: "🇸🇬", symbol: "S$", rateFromINR: 1 / 61 },
  { code: "CAD", flag: "🇨🇦", symbol: "C$", rateFromINR: 1 / 61 },
];

interface CurrencyContextType {
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  format: (inrAmount: number) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrencyState] = useState<CurrencyCode>(
    () => (localStorage.getItem("cet_currency") as CurrencyCode) || "INR"
  );

  const setCurrency = (c: CurrencyCode) => {
    localStorage.setItem("cet_currency", c);
    setCurrencyState(c);
  };

  const format = (inrAmount: number): string => {
    const cur = CURRENCIES.find(c => c.code === currency)!;
    const converted = inrAmount * cur.rateFromINR;
    const formatted = converted < 10
      ? converted.toFixed(2)
      : Math.round(converted).toLocaleString("en-US");
    return `${cur.symbol}${formatted}`;
  };

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, format }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export const useCurrency = () => {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error("useCurrency must be inside CurrencyProvider");
  return ctx;
};
