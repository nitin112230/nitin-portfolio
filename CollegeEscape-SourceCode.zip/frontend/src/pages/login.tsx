import { useLogin } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Login() {
  const login = useLogin();
  const { setToken } = useAuth();
  const [, setLocation] = useLocation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login.mutate({
      data: { email, password }
    }, {
      onSuccess: (res) => {
        setToken(res.token);
        setLocation("/trips");
      }
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-background pointer-events-none" />
      
      <div className="w-full max-w-md bg-card border border-border p-8 rounded-2xl relative z-10">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-black mb-2 uppercase">Welcome Back</h1>
          <p className="text-muted-foreground font-sans">Login to see your epic escapes.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-bold mb-2 uppercase text-muted-foreground">Email</label>
            <input 
              type="email" 
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-bold mb-2 uppercase text-muted-foreground">Password</label>
            <input 
              type="password" 
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary transition-colors"
            />
          </div>
          
          <Button 
            type="submit" 
            disabled={login.isPending}
            className="w-full h-14 text-lg font-bold uppercase tracking-wider mt-4"
          >
            {login.isPending ? 'Authenticating...' : 'Enter the Party'}
          </Button>
        </form>

        <div className="mt-8 text-center text-sm font-sans text-muted-foreground">
          Don't have an account? <Link href="/register" className="text-primary hover:underline">Sign up</Link>
        </div>
      </div>
    </div>
  );
}
