import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

const ADMIN_KEY = import.meta.env.VITE_ADMIN_KEY as string;
const API = import.meta.env.BASE_URL.replace(/\/$/, "") + "/api";

function adminHeaders() {
  return { "Content-Type": "application/json", "x-admin-key": ADMIN_KEY };
}

type Overview = { totalTrips: number; totalUsers: number; totalBookings: number; confirmedBookings: number; totalSeatsBooked: number };
type Trip = { id: number; title: string; destination: string; price: number; duration: string; departureDate: string; returnDate: string; availableSeats: number; totalSeats: number; status: string };
type Booking = { id: number; tripTitle: string; tripDestination: string; userName: string; userEmail: string; userCollege: string; userPhone: string; numberOfPeople: number; totalAmount: number; status: string; specialRequests: string | null; createdAt: string };
type User = { id: number; name: string; email: string; college: string; phone: string | null; bookingCount: number; createdAt: string };

export default function Admin() {
  const [authed, setAuthed] = useState(() => sessionStorage.getItem("admin_authed") === "yes");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [tab, setTab] = useState<"overview" | "trips" | "bookings" | "users">("overview");

  const [overview, setOverview] = useState<Overview | null>(null);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  const [saving, setSaving] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_KEY) {
      sessionStorage.setItem("admin_authed", "yes");
      setAuthed(true);
      setError("");
    } else {
      setError("Galat password. Dobara try karo.");
    }
  };

  const fetchAll = async () => {
    const [ov, tr, bk, us] = await Promise.all([
      fetch(`${API}/admin/overview`, { headers: adminHeaders() }).then(r => r.json()),
      fetch(`${API}/admin/trips`, { headers: adminHeaders() }).then(r => r.json()),
      fetch(`${API}/admin/bookings`, { headers: adminHeaders() }).then(r => r.json()),
      fetch(`${API}/admin/users`, { headers: adminHeaders() }).then(r => r.json()),
    ]);
    setOverview(ov);
    setTrips(tr);
    setBookings(bk);
    setUsers(us);
  };

  useEffect(() => { if (authed) fetchAll(); }, [authed]);

  const saveTrip = async () => {
    if (!editingTrip) return;
    setSaving(true);
    await fetch(`${API}/admin/trips/${editingTrip.id}`, {
      method: "PUT",
      headers: adminHeaders(),
      body: JSON.stringify({
        price: editingTrip.price,
        availableSeats: editingTrip.availableSeats,
        status: editingTrip.status,
        title: editingTrip.title,
        destination: editingTrip.destination,
        departureDate: editingTrip.departureDate,
        returnDate: editingTrip.returnDate,
      }),
    });
    await fetchAll();
    setEditingTrip(null);
    setSaving(false);
  };

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-sm bg-card border border-border rounded-2xl p-8">
          <h1 className="text-3xl font-black mb-2 uppercase text-center">Admin</h1>
          <p className="text-muted-foreground text-sm text-center mb-8 font-sans">Sirf authorized access</p>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="password"
              placeholder="Admin password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary"
              autoFocus
            />
            {error && <p className="text-red-500 text-sm font-sans">{error}</p>}
            <Button type="submit" className="w-full h-12 font-bold uppercase tracking-wider">Enter</Button>
          </form>
        </div>
      </div>
    );
  }

  const tabs: { key: typeof tab; label: string }[] = [
    { key: "overview", label: "Overview" },
    { key: "trips", label: `Trips (${trips.length})` },
    { key: "bookings", label: `Bookings (${bookings.length})` },
    { key: "users", label: `Students (${users.length})` },
  ];

  return (
    <div className="min-h-screen py-10 px-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-black uppercase">Admin Dashboard</h1>
        <button
          onClick={() => { sessionStorage.removeItem("admin_authed"); setAuthed(false); }}
          className="text-sm text-muted-foreground hover:text-primary font-bold uppercase"
        >
          Logout
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-8 border-b border-border overflow-x-auto pb-px">
        {tabs.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-5 py-2.5 font-bold uppercase text-sm whitespace-nowrap border-b-2 transition-colors ${tab === t.key ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === "overview" && overview && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {[
            { label: "Total Trips", value: overview.totalTrips },
            { label: "Registered Students", value: overview.totalUsers },
            { label: "Total Bookings", value: overview.totalBookings },
            { label: "Confirmed Bookings", value: overview.confirmedBookings },
            { label: "Total Seats Booked", value: overview.totalSeatsBooked },
          ].map(stat => (
            <div key={stat.label} className="bg-card border border-border rounded-xl p-6">
              <div className="text-4xl font-black text-primary mb-2">{stat.value}</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider font-sans">{stat.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Trips */}
      {tab === "trips" && (
        <div className="space-y-4">
          {trips.map(trip => (
            <div key={trip.id} className="bg-card border border-border rounded-xl p-6">
              {editingTrip?.id === trip.id ? (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Title</label>
                      <input value={editingTrip.title} onChange={e => setEditingTrip({ ...editingTrip, title: e.target.value })}
                        className="w-full bg-input border border-border rounded px-3 py-2 font-sans focus:outline-none focus:border-primary" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Destination</label>
                      <input value={editingTrip.destination} onChange={e => setEditingTrip({ ...editingTrip, destination: e.target.value })}
                        className="w-full bg-input border border-border rounded px-3 py-2 font-sans focus:outline-none focus:border-primary" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Price (₹)</label>
                      <input type="number" value={editingTrip.price} onChange={e => setEditingTrip({ ...editingTrip, price: Number(e.target.value) })}
                        className="w-full bg-input border border-border rounded px-3 py-2 font-sans focus:outline-none focus:border-primary" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Available Seats</label>
                      <input type="number" value={editingTrip.availableSeats} onChange={e => setEditingTrip({ ...editingTrip, availableSeats: Number(e.target.value) })}
                        className="w-full bg-input border border-border rounded px-3 py-2 font-sans focus:outline-none focus:border-primary" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Departure Date</label>
                      <input type="date" value={editingTrip.departureDate} onChange={e => setEditingTrip({ ...editingTrip, departureDate: e.target.value })}
                        className="w-full bg-input border border-border rounded px-3 py-2 font-sans focus:outline-none focus:border-primary" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Return Date</label>
                      <input type="date" value={editingTrip.returnDate} onChange={e => setEditingTrip({ ...editingTrip, returnDate: e.target.value })}
                        className="w-full bg-input border border-border rounded px-3 py-2 font-sans focus:outline-none focus:border-primary" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground uppercase mb-1 block">Status</label>
                      <select value={editingTrip.status} onChange={e => setEditingTrip({ ...editingTrip, status: e.target.value })}
                        className="w-full bg-input border border-border rounded px-3 py-2 font-sans focus:outline-none focus:border-primary">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="sold_out">Sold Out</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex gap-3 pt-2">
                    <Button onClick={saveTrip} disabled={saving} className="font-bold uppercase">{saving ? "Saving..." : "Save"}</Button>
                    <Button variant="outline" onClick={() => setEditingTrip(null)} className="font-bold uppercase">Cancel</Button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-xl font-bold uppercase">{trip.title}</h3>
                      <span className={`text-xs font-bold uppercase px-2 py-0.5 rounded ${trip.status === "active" ? "bg-green-500/20 text-green-400" : "bg-muted text-muted-foreground"}`}>
                        {trip.status}
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground font-sans">
                      {trip.destination} &nbsp;•&nbsp; {trip.duration} &nbsp;•&nbsp;
                      {trip.price > 0 ? <span className="text-primary font-bold">₹{trip.price}</span> : <span className="text-yellow-500 font-bold">Price not set</span>}
                      &nbsp;•&nbsp; {trip.availableSeats}/{trip.totalSeats} seats left
                    </div>
                  </div>
                  <Button variant="outline" onClick={() => setEditingTrip(trip)} className="font-bold uppercase text-sm shrink-0">Edit</Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Bookings */}
      {tab === "bookings" && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm font-sans">
            <thead>
              <tr className="border-b border-border text-left text-muted-foreground uppercase text-xs tracking-wider">
                <th className="pb-3 pr-4">#</th>
                <th className="pb-3 pr-4">Student</th>
                <th className="pb-3 pr-4">College</th>
                <th className="pb-3 pr-4">Phone</th>
                <th className="pb-3 pr-4">Trip</th>
                <th className="pb-3 pr-4">People</th>
                <th className="pb-3 pr-4">Status</th>
                <th className="pb-3">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {bookings.map(b => (
                <tr key={b.id} className="hover:bg-card/50 transition-colors">
                  <td className="py-4 pr-4 text-muted-foreground">#{b.id}</td>
                  <td className="py-4 pr-4">
                    <div className="font-bold">{b.userName}</div>
                    <div className="text-muted-foreground text-xs">{b.userEmail}</div>
                  </td>
                  <td className="py-4 pr-4 text-muted-foreground">{b.userCollege}</td>
                  <td className="py-4 pr-4 text-muted-foreground">{b.userPhone || "—"}</td>
                  <td className="py-4 pr-4">
                    <div className="font-bold">{b.tripTitle}</div>
                    <div className="text-muted-foreground text-xs">{b.tripDestination}</div>
                  </td>
                  <td className="py-4 pr-4 text-center">{b.numberOfPeople}</td>
                  <td className="py-4 pr-4">
                    <span className={`text-xs font-bold uppercase px-2 py-1 rounded ${b.status === "confirmed" ? "bg-green-500/20 text-green-400" : "bg-yellow-500/20 text-yellow-400"}`}>
                      {b.status}
                    </span>
                  </td>
                  <td className="py-4 text-muted-foreground text-xs">{new Date(b.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
              {!bookings.length && (
                <tr><td colSpan={8} className="py-12 text-center text-muted-foreground">Abhi koi booking nahi hai.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Users */}
      {tab === "users" && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm font-sans">
            <thead>
              <tr className="border-b border-border text-left text-muted-foreground uppercase text-xs tracking-wider">
                <th className="pb-3 pr-4">#</th>
                <th className="pb-3 pr-4">Name</th>
                <th className="pb-3 pr-4">Email</th>
                <th className="pb-3 pr-4">College</th>
                <th className="pb-3 pr-4">Phone</th>
                <th className="pb-3 pr-4">Bookings</th>
                <th className="pb-3">Joined</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-card/50 transition-colors">
                  <td className="py-4 pr-4 text-muted-foreground">#{u.id}</td>
                  <td className="py-4 pr-4 font-bold">{u.name}</td>
                  <td className="py-4 pr-4 text-muted-foreground">{u.email}</td>
                  <td className="py-4 pr-4 text-muted-foreground">{u.college}</td>
                  <td className="py-4 pr-4 text-muted-foreground">{u.phone || "—"}</td>
                  <td className="py-4 pr-4 text-center">
                    <span className="bg-primary/20 text-primary px-2 py-0.5 rounded font-bold">{u.bookingCount}</span>
                  </td>
                  <td className="py-4 text-muted-foreground text-xs">{new Date(u.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
              {!users.length && (
                <tr><td colSpan={7} className="py-12 text-center text-muted-foreground">Abhi koi student registered nahi hai.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
