import { useListTrips, useCreateBooking, useGetTrip } from "@workspace/api-client-react";
import { Link } from "wouter";
import { useState } from "react";
import { useCurrency } from "@/lib/currency";

type Category = "ALL" | "BEACH" | "MOUNTAINS" | "CITY" | "NATURE" | "INTERNATIONAL";
const CATEGORIES: Category[] = ["ALL", "BEACH", "MOUNTAINS", "CITY", "NATURE", "INTERNATIONAL"];

const COUNTRY_CODES = [
  { code: "+91", flag: "🇮🇳", label: "India" },
  { code: "+1", flag: "🇺🇸", label: "USA" },
  { code: "+44", flag: "🇬🇧", label: "UK" },
  { code: "+971", flag: "🇦🇪", label: "UAE" },
  { code: "+61", flag: "🇦🇺", label: "Australia" },
  { code: "+65", flag: "🇸🇬", label: "Singapore" },
  { code: "+1", flag: "🇨🇦", label: "Canada" },
  { code: "+60", flag: "🇲🇾", label: "Malaysia" },
];

function isInternational(destination: string) {
  return ["thailand", "indonesia", "uae", "dubai", "bali", "bangkok", "singapore", "malaysia"].some(k =>
    destination.toLowerCase().includes(k)
  );
}

function getCategory(destination: string): Category {
  if (isInternational(destination)) return "INTERNATIONAL";
  const d = destination.toLowerCase();
  if (d.includes("goa") || d.includes("pondicherry") || d.includes("puducherry")) return "BEACH";
  if (d.includes("manali") || d.includes("kasol") || d.includes("rishikesh")) return "MOUNTAINS";
  if (d.includes("rajasthan")) return "CITY";
  if (d.includes("coorg")) return "NATURE";
  return "ALL";
}

function getBadge(title: string, destination: string) {
  if (isInternational(destination)) {
    if (title.toLowerCase().includes("dubai")) return { text: "PREMIUM INTERNATIONAL", color: "from-yellow-400 to-orange-500" };
    return { text: "INTERNATIONAL", color: "from-yellow-300 to-yellow-500" };
  }
  const t = title.toLowerCase();
  if (t.includes("goa")) return { text: "MOST POPULAR", color: "from-pink-500 to-orange-400" };
  if (t.includes("manali")) return { text: "NEW", color: "from-cyan-400 to-blue-500" };
  if (t.includes("kasol") || t.includes("rishikesh")) return { text: "ADVENTURE", color: "from-green-400 to-emerald-600" };
  if (t.includes("pondicherry") || t.includes("puducherry")) return { text: "CHILL", color: "from-sky-400 to-cyan-500" };
  if (t.includes("coorg")) return { text: "NATURE", color: "from-lime-400 to-green-600" };
  if (t.includes("rajasthan")) return { text: "PREMIUM", color: "from-yellow-400 to-orange-500" };
  return { text: "HOT", color: "from-pink-500 to-purple-600" };
}

interface BookingModalProps {
  tripId: number;
  tripDestination: string;
  onClose: () => void;
}

function BookingModal({ tripId, tripDestination, onClose }: BookingModalProps) {
  const { data: trip } = useGetTrip(tripId, { query: { enabled: true, queryKey: ["trip-modal", tripId] } });
  const createBooking = useCreateBooking();
  const { format } = useCurrency();

  const intl = isInternational(tripDestination);

  const [name, setName] = useState("");
  const [college, setCollege] = useState("");
  const [countryCode, setCountryCode] = useState("+91");
  const [phone, setPhone] = useState("");
  const [country, setCountry] = useState("India");
  const [passport, setPassport] = useState(false);
  const [people, setPeople] = useState(1);
  const [date, setDate] = useState("");
  const [success, setSuccess] = useState(false);

  const price = trip?.price ?? 0;
  const total = price * people;

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    const requests = `Name: ${name} | College: ${college} | Phone: ${countryCode}${phone} | Country: ${country}${intl ? " | Passport: " + (passport ? "Yes" : "No") : ""} | Date: ${date}`;
    createBooking.mutate({ data: { tripId, numberOfPeople: people, specialRequests: requests } }, {
      onSuccess: () => setSuccess(true)
    });
  };

  const inputClass = "w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 font-sans text-sm focus:outline-none focus:border-[#FF2D9B] transition-colors";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative w-full max-w-lg rounded-2xl border bg-[#0a0010]/95 backdrop-blur-xl p-6 md:p-8 shadow-[0_0_60px_#FF2D9B33] max-h-[90vh] overflow-y-auto"
        style={{ borderColor: intl ? "rgba(255,215,0,0.4)" : "rgba(255,45,155,0.4)" }}
        onClick={e => e.stopPropagation()}>

        {success ? (
          <div className="text-center py-8">
            <div className="text-6xl mb-4">🎉</div>
            <h3 className="text-2xl font-black mb-3 bg-gradient-to-r from-[#FF2D9B] to-[#00D4FF] bg-clip-text text-transparent">Booking Confirmed!</h3>
            <p className="text-muted-foreground font-sans mb-6">We'll WhatsApp you shortly on <span className="text-white font-bold">{countryCode}{phone}</span> with all details.</p>
            <a href={`https://wa.me/919599896274?text=Hi! I booked ${trip?.title} for ${people} person(s). Name: ${name}, College: ${college}, Phone: ${countryCode}${phone}`}
              target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] text-white font-bold px-6 py-3 rounded-lg hover:bg-[#25D366]/90 transition-colors">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              Chat on WhatsApp
            </a>
            <button onClick={onClose} className="block w-full mt-4 text-sm text-muted-foreground hover:text-foreground">Close</button>
          </div>
        ) : (
          <>
            <div className="flex justify-between items-start mb-5">
              <div>
                <h3 className="text-xl font-black uppercase">{trip?.title}</h3>
                <p className="text-muted-foreground text-sm font-sans">{trip?.destination} &nbsp;•&nbsp; {trip?.duration}</p>
              </div>
              <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-2xl leading-none ml-4">&times;</button>
            </div>

            <form onSubmit={handleConfirm} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-muted-foreground mb-1">Full Name</label>
                  <input required value={name} onChange={e => setName(e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-muted-foreground mb-1">College / University</label>
                  <input required value={college} onChange={e => setCollege(e.target.value)} className={inputClass} />
                </div>
              </div>

              {/* Phone with country code */}
              <div>
                <label className="block text-xs font-bold uppercase text-muted-foreground mb-1">
                  Phone Number <span className="normal-case text-muted-foreground/60">(e.g. +1 234 567 8900)</span>
                </label>
                <div className="flex gap-2">
                  <select value={countryCode} onChange={e => setCountryCode(e.target.value)}
                    className="bg-white/5 border border-white/10 rounded-lg px-2 py-2.5 font-sans text-sm focus:outline-none focus:border-[#FF2D9B] transition-colors w-28">
                    {COUNTRY_CODES.map(c => (
                      <option key={c.label} value={c.code}>{c.flag} {c.code}</option>
                    ))}
                  </select>
                  <input required type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                    placeholder="Phone number" className={`${inputClass} flex-1`} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-muted-foreground mb-1">Country of Residence</label>
                  <select value={country} onChange={e => setCountry(e.target.value)} className={inputClass}>
                    {["India", "USA", "UK", "UAE", "Australia", "Singapore", "Canada", "Malaysia", "Other"].map(c => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-muted-foreground mb-1">No. of People</label>
                  <select value={people} onChange={e => setPeople(Number(e.target.value))} className={inputClass}>
                    {[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{n} {n === 1 ? "person" : "people"}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-muted-foreground mb-1">Select Trip Date</label>
                <input required type="date" value={date} onChange={e => setDate(e.target.value)}
                  min={trip?.departureDate} className={inputClass} />
              </div>

              {/* Passport checkbox for international */}
              {intl && (
                <label className="flex items-center gap-3 cursor-pointer bg-white/5 border border-[#FFD700]/30 rounded-lg px-4 py-3">
                  <input type="checkbox" checked={passport} onChange={e => setPassport(e.target.checked)}
                    className="w-4 h-4 accent-[#FFD700]" />
                  <span className="text-sm font-bold text-[#FFD700]">I have a valid passport (required for international trips)</span>
                </label>
              )}

              {/* Price calc */}
              {price > 0 && (
                <div className="bg-white/5 rounded-xl p-4 border border-white/10 font-sans text-sm">
                  <div className="flex justify-between text-muted-foreground mb-1">
                    <span>{format(price)} × {people} {people === 1 ? "person" : "people"}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-bold">Total</span>
                    <span className="text-xl font-black bg-gradient-to-r from-[#FF2D9B] to-[#00D4FF] bg-clip-text text-transparent">{format(total)}</span>
                  </div>
                </div>
              )}

              {/* Payment note */}
              <div className="bg-white/3 border border-white/10 rounded-lg px-4 py-3 text-xs text-muted-foreground font-sans">
                <span className="font-bold text-foreground">Payment: </span>
                UPI (India) &nbsp;|&nbsp; PayPal &nbsp;|&nbsp; Wise Transfer &nbsp;|&nbsp; Bank Transfer (International)
              </div>

              <button type="submit" disabled={createBooking.isPending || (intl && !passport)}
                className="w-full h-14 rounded-xl font-black uppercase tracking-widest text-white text-lg transition-all duration-300 hover:shadow-[0_0_30px_#FF2D9B66] disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ background: intl ? "linear-gradient(90deg,#FFD700,#FF8C00)" : "linear-gradient(90deg,#FF2D9B,#00D4FF)" }}>
                {createBooking.isPending ? "Confirming..." : "CONFIRM BOOKING"}
              </button>
              {intl && !passport && (
                <p className="text-xs text-[#FFD700] text-center font-sans">Please confirm you have a valid passport to proceed.</p>
              )}
            </form>
          </>
        )}
      </div>
    </div>
  );
}

export default function Trips() {
  const { data: trips, isLoading } = useListTrips();
  const { format } = useCurrency();
  const [activeCategory, setActiveCategory] = useState<Category>("ALL");
  const [bookingTrip, setBookingTrip] = useState<{ id: number; destination: string } | null>(null);

  const filtered = (trips ?? []).filter(trip =>
    activeCategory === "ALL" || getCategory(trip.destination) === activeCategory
  );

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <div className="text-center pt-20 pb-12 px-6">
        <h1 className="text-5xl md:text-7xl font-black mb-4 bg-gradient-to-r from-[#FF2D9B] via-white to-[#00D4FF] bg-clip-text text-transparent uppercase tracking-tight">
          ESCAPE DESTINATIONS
        </h1>
        <p className="text-xl text-muted-foreground font-sans">Pick your vibe. Book your escape. Make memories.</p>
      </div>

      {/* Filter Bar */}
      <div className="flex justify-center gap-2 flex-wrap px-6 mb-12">
        {CATEGORIES.map(cat => (
          <button key={cat} onClick={() => setActiveCategory(cat)}
            className={`px-5 py-2 rounded-full text-sm font-black uppercase tracking-wider transition-all duration-300 ${
              activeCategory === cat
                ? cat === "INTERNATIONAL"
                  ? "text-black shadow-[0_0_20px_#FFD70066]"
                  : "text-white shadow-[0_0_20px_#FF2D9B66]"
                : "bg-white/5 border border-white/10 text-muted-foreground hover:border-[#FF2D9B]/50 hover:text-white"
            }`}
            style={activeCategory === cat ? {
              background: cat === "INTERNATIONAL"
                ? "linear-gradient(90deg,#FFD700,#FF8C00)"
                : "linear-gradient(90deg,#FF2D9B,#00D4FF)"
            } : {}}>
            {cat === "INTERNATIONAL" ? "✈️ INTL" : cat}
          </button>
        ))}
      </div>

      {/* Cards */}
      {isLoading ? (
        <div className="text-center py-20 text-muted-foreground">Loading trips...</div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 px-6 max-w-7xl mx-auto">
          {filtered.map((trip, i) => {
            const badge = getBadge(trip.title, trip.destination);
            const intl = isInternational(trip.destination);
            const slots = trip.availableSeats;
            const total = trip.totalSeats;
            const slotPct = Math.max(0, Math.min(100, (slots / total) * 100));
            const isSoldOut = slots === 0;
            const isLow = slots > 0 && slots < 5;
            const isFilling = slots >= 5 && slots < 10;

            return (
              <div key={trip.id}
                className="animate-fade-in-up group relative rounded-2xl overflow-hidden border transition-all duration-500 hover:scale-[1.02]"
                style={{
                  animationDelay: `${i * 60}ms`,
                  background: intl
                    ? "linear-gradient(135deg,rgba(255,215,0,0.06),rgba(10,0,20,0.95),rgba(255,140,0,0.06))"
                    : "linear-gradient(135deg,rgba(255,45,155,0.05),rgba(10,0,20,0.95),rgba(0,212,255,0.05))",
                  borderColor: intl ? "rgba(255,215,0,0.25)" : "rgba(255,45,155,0.25)",
                  backdropFilter: "blur(20px)",
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.borderColor = intl ? "rgba(255,215,0,0.7)" : "rgba(255,45,155,0.7)";
                  (e.currentTarget as HTMLElement).style.boxShadow = intl
                    ? "0 0 30px rgba(255,215,0,0.25), 0 0 60px rgba(255,140,0,0.1)"
                    : "0 0 30px rgba(255,45,155,0.3), 0 0 60px rgba(0,212,255,0.1)";
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.borderColor = intl ? "rgba(255,215,0,0.25)" : "rgba(255,45,155,0.25)";
                  (e.currentTarget as HTMLElement).style.boxShadow = "none";
                }}>

                {/* Shimmer */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none animate-shimmer" />

                {/* Image */}
                <div className="relative h-52 overflow-hidden">
                  {trip.imageUrl && <img src={trip.imageUrl} alt={trip.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0010] via-[#0a0010]/40 to-transparent" />
                  <div className={`absolute top-4 right-4 bg-gradient-to-r ${badge.color} text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-lg ${intl ? "text-black" : "text-white"}`}>
                    {badge.text}
                  </div>
                  {isSoldOut && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <span className="bg-red-600 text-white font-black text-xl px-6 py-2 rounded-full uppercase rotate-[-8deg]">SOLD OUT</span>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <div className="flex justify-between items-start gap-2">
                    <h3 className="text-xl font-black uppercase leading-tight group-hover:text-[#FF2D9B] transition-colors">{trip.title}</h3>
                    <span className="shrink-0 bg-white/10 border border-white/10 text-xs font-bold px-2 py-1 rounded-full text-muted-foreground whitespace-nowrap">{trip.duration}</span>
                  </div>

                  {trip.price > 0 && (
                    <div className="text-2xl font-black" style={{
                      background: intl ? "linear-gradient(90deg,#FFD700,#FF8C00)" : "linear-gradient(90deg,#FF2D9B,#00D4FF)",
                      WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent"
                    }}>
                      {format(trip.price)}
                      <span className="text-sm font-sans ml-1" style={{ WebkitTextFillColor: "hsl(var(--muted-foreground))", background: "none" }}>/person</span>
                    </div>
                  )}

                  {/* Slots */}
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className={`text-sm font-bold ${isLow ? "animate-pulse-red animate-slot-pulse" : isFilling ? "text-yellow-400" : "text-muted-foreground"}`}>
                        {isSoldOut ? "No slots left" : `${slots} slots left`}
                      </span>
                      {isFilling && !isLow && <span className="text-xs text-yellow-400 font-bold">Filling Fast!</span>}
                      {isLow && <span className="text-xs text-red-400 font-bold animate-pulse">Hurry!</span>}
                    </div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${slotPct}%`,
                          background: intl ? "linear-gradient(90deg,#FFD700,#FF8C00)" : "linear-gradient(90deg,#FF2D9B,#00D4FF)",
                          boxShadow: intl ? "0 0 6px #FFD70088" : "0 0 6px #FF2D9B88",
                        }} />
                    </div>
                  </div>

                  {/* Includes */}
                  <div className="grid grid-cols-2 gap-1">
                    {trip.includes.slice(0, 4).map((item, j) => (
                      <div key={j} className="flex items-center gap-1.5 text-xs text-muted-foreground font-sans">
                        <span style={{ color: intl ? "#FFD700" : "#00D4FF" }} className="font-bold">✓</span>
                        <span className="truncate">{item}</span>
                      </div>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3 pt-2">
                    {isSoldOut ? (
                      <button disabled className="flex-1 h-12 rounded-xl font-black uppercase tracking-wider bg-white/10 text-muted-foreground cursor-not-allowed">SOLD OUT</button>
                    ) : (
                      <button onClick={() => setBookingTrip({ id: trip.id, destination: trip.destination })}
                        className="flex-1 h-12 rounded-xl font-black uppercase tracking-wider text-white transition-all duration-300 hover:scale-[1.02]"
                        style={{
                          background: intl ? "linear-gradient(90deg,#FFD700,#FF8C00)" : "linear-gradient(90deg,#FF2D9B,#00D4FF)",
                          boxShadow: intl ? "none" : "none",
                          color: intl ? "#000" : "#fff",
                        }}
                        onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = intl ? "0 0 25px rgba(255,215,0,0.6)" : "0 0 25px rgba(255,45,155,0.6)"; }}
                        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}>
                        BOOK NOW
                      </button>
                    )}
                    <Link href={`/trips/${trip.id}`}
                      className="h-12 px-4 rounded-xl border border-white/20 text-sm font-bold uppercase flex items-center justify-center text-muted-foreground hover:border-[#00D4FF]/60 hover:text-white transition-colors">
                      Details
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && !isLoading && (
            <div className="col-span-full text-center py-20 text-muted-foreground">Is category mein koi trip nahi hai abhi.</div>
          )}
        </div>
      )}

      {/* Booking Modal */}
      {bookingTrip && <BookingModal tripId={bookingTrip.id} tripDestination={bookingTrip.destination} onClose={() => setBookingTrip(null)} />}
    </div>
  );
}
