import { useParams, useLocation } from "wouter";
import { useGetTrip, useCreateBooking } from "@workspace/api-client-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function TripDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const tripId = Number(id);
  
  const { data: trip, isLoading } = useGetTrip(tripId, {
    query: {
      enabled: !!tripId,
      queryKey: ["useGetTrip", tripId]
    }
  });

  const createBooking = useCreateBooking();

  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [specialRequests, setSpecialRequests] = useState("");

  if (isLoading) return <div className="p-24 text-center">Loading...</div>;
  if (!trip) return <div className="p-24 text-center">Trip not found</div>;

  const handleBook = () => {
    createBooking.mutate({
      data: {
        tripId: trip.id,
        numberOfPeople,
        specialRequests
      }
    }, {
      onSuccess: (booking) => {
        setLocation(`/payment/${booking.id}`);
      }
    });
  };

  return (
    <div className="min-h-screen pb-24">
      {/* Hero */}
      <div className="relative h-[60vh] flex items-end pb-12 px-6">
        <div className="absolute inset-0 z-0">
          {trip.imageUrl ? (
            <img src={trip.imageUrl} alt={trip.title} className="w-full h-full object-cover opacity-50" />
          ) : (
            <div className="w-full h-full bg-muted" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto w-full">
          <div className="mb-4 inline-block bg-primary/20 text-primary border border-primary/50 px-4 py-1 rounded-full text-sm font-bold uppercase tracking-wider">
            {trip.destination}
          </div>
          <h1 className="text-5xl md:text-7xl font-black uppercase mb-4">{trip.title}</h1>
          <div className="flex flex-wrap gap-6 text-lg">
            <div><span className="text-muted-foreground mr-2">DURATION</span><span className="font-bold">{trip.duration}</span></div>
            <div><span className="text-muted-foreground mr-2">DATES</span><span className="font-bold">{new Date(trip.departureDate).toLocaleDateString()} - {new Date(trip.returnDate).toLocaleDateString()}</span></div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-3 gap-12 mt-12">
        <div className="lg:col-span-2 space-y-16">
          <section>
            <h2 className="text-3xl font-bold mb-6">THE VIBE</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">{trip.description}</p>
          </section>

          <section>
            <h2 className="text-3xl font-bold mb-6">NIGHTLIFE GUIDE</h2>
            <div className="grid sm:grid-cols-2 gap-6">
              {trip.partyPlaces.map((place, i) => (
                <div key={i} className="bg-card border border-border p-6 rounded-xl hover:border-primary transition-colors">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold uppercase">{place.name}</h3>
                    <span className="bg-secondary/20 text-secondary text-xs px-2 py-1 rounded font-bold uppercase">{place.type}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 h-10">{place.description}</p>
                  <div className="text-sm border-t border-border pt-4 flex justify-between">
                    <span className="text-muted-foreground">{place.timings}</span>
                    {place.entryFee && <span className="font-bold text-accent">{place.entryFee}</span>}
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="grid sm:grid-cols-2 gap-12">
            <section>
              <h2 className="text-2xl font-bold mb-4">HIGHLIGHTS</h2>
              <ul className="space-y-3">
                {trip.highlights.map((h, i) => (
                  <li key={i} className="flex gap-3 text-muted-foreground">
                    <span className="text-primary">▹</span> {h}
                  </li>
                ))}
              </ul>
            </section>
            <section>
              <h2 className="text-2xl font-bold mb-4">INCLUDED</h2>
              <ul className="space-y-3">
                {trip.includes.map((h, i) => (
                  <li key={i} className="flex gap-3 text-muted-foreground">
                    <span className="text-secondary">▹</span> {h}
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-card border border-border p-8 rounded-xl sticky top-24">
            <h3 className="text-2xl font-bold mb-6">SECURE YOUR SPOT</h3>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold mb-2 text-muted-foreground">NUMBER OF PEOPLE</label>
                <input 
                  type="number" 
                  min="1" 
                  max={trip.availableSeats}
                  value={numberOfPeople}
                  onChange={e => setNumberOfPeople(Number(e.target.value))}
                  className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary"
                />
              </div>
              
              <div>
                <label className="block text-sm font-bold mb-2 text-muted-foreground">SPECIAL REQUESTS</label>
                <textarea 
                  value={specialRequests}
                  onChange={e => setSpecialRequests(e.target.value)}
                  className="w-full bg-input border border-border rounded-md px-4 py-3 h-24 font-sans focus:outline-none focus:border-primary resize-none"
                  placeholder="Any dietary reqs or room preferences?"
                />
              </div>

              <Button 
                onClick={handleBook} 
                disabled={createBooking.isPending}
                className="w-full h-14 text-lg font-bold uppercase tracking-wider"
              >
                {createBooking.isPending ? 'Booking...' : 'Book Now'}
              </Button>

              <a
                href={`https://wa.me/919599896274?text=Hi! I'm interested in the trip: ${encodeURIComponent(trip.title)} (${encodeURIComponent(trip.destination)}). Please share more details.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 w-full h-14 rounded-md border-2 border-[#25D366] text-[#25D366] font-bold text-lg uppercase tracking-wider hover:bg-[#25D366]/10 transition-colors"
              >
                <svg viewBox="0 0 24 24" className="w-6 h-6 fill-[#25D366]" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                Enquire on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
