import { useListBookings } from "@workspace/api-client-react";
import { Link } from "wouter";

export default function MyTrips() {
  const { data: bookings, isLoading } = useListBookings();

  if (isLoading) return <div className="p-24 text-center">Loading...</div>;

  return (
    <div className="min-h-screen py-24 px-6 max-w-5xl mx-auto">
      <h1 className="text-5xl font-black mb-12 uppercase text-center">My Escapes</h1>

      {!bookings?.length ? (
        <div className="text-center bg-card border border-border p-12 rounded-2xl">
          <h2 className="text-2xl font-bold mb-4">No trips booked yet</h2>
          <p className="text-muted-foreground mb-8">Your next big story is waiting.</p>
          <Link href="/trips" className="bg-primary text-primary-foreground px-8 py-3 rounded-md font-bold hover:bg-primary/90">
            BROWSE TRIPS
          </Link>
        </div>
      ) : (
        <div className="space-y-6">
          {bookings.map(booking => (
            <div key={booking.id} className="bg-card border border-border p-6 rounded-xl flex flex-col md:flex-row justify-between items-center gap-6">
              <div>
                <div className="flex items-center gap-4 mb-2">
                  <h3 className="text-2xl font-bold uppercase">{booking.trip?.title}</h3>
                  <span className={`px-3 py-1 rounded text-xs font-bold uppercase ${booking.status === 'CONFIRMED' ? 'bg-secondary/20 text-secondary' : 'bg-muted text-muted-foreground'}`}>
                    {booking.status}
                  </span>
                </div>
                <div className="text-muted-foreground font-sans">
                  {booking.numberOfPeople} People
                </div>
              </div>
              <Link 
                href={`/trips/${booking.tripId}`}
                className="whitespace-nowrap px-6 py-3 border border-border rounded hover:bg-muted transition-colors font-bold uppercase text-sm"
              >
                View Trip
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
