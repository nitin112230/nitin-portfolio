import { useParams } from "wouter";
import { useGetBooking, useInitiatePayment, useConfirmPayment } from "@workspace/api-client-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Payment() {
  const { bookingId } = useParams();
  const bId = Number(bookingId);

  const { data: booking, isLoading } = useGetBooking(bId, {
    query: { enabled: !!bId, queryKey: ["useGetBooking", bId] }
  });

  const initiatePayment = useInitiatePayment();
  const confirmPayment = useConfirmPayment();

  const [method, setMethod] = useState("UPI");
  const [success, setSuccess] = useState(false);

  if (isLoading) return <div className="p-24 text-center">Loading...</div>;
  if (!booking) return <div className="p-24 text-center">Booking not found</div>;

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="bg-card border border-border p-12 rounded-2xl max-w-lg w-full text-center">
          <div className="w-20 h-20 bg-primary/20 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-4xl">✓</span>
          </div>
          <h2 className="text-3xl font-black uppercase mb-4">Payment Successful!</h2>
          <p className="text-muted-foreground mb-8">Your spot is secured. Pack your bags.</p>
          <div className="bg-muted p-4 rounded-lg mb-8 text-left font-sans">
            <div className="mb-2"><span className="text-muted-foreground">Booking ID:</span> <span className="font-bold text-foreground">#{booking.id}</span></div>
            <div><span className="text-muted-foreground">People:</span> <span className="font-bold text-foreground">{booking.numberOfPeople}</span></div>
          </div>
          <Button asChild className="w-full"><a href="/my-trips">View My Trips</a></Button>
        </div>
      </div>
    );
  }

  const handlePay = () => {
    initiatePayment.mutate({
      data: {
        bookingId: bId,
        method: method,
        upiId: method === 'UPI' ? 'user@upi' : undefined,
        cardNumber: method === 'CARD' ? '4111111111111111' : undefined
      }
    }, {
      onSuccess: (payment) => {
        // simulate payment confirmation
        setTimeout(() => {
          confirmPayment.mutate({
            data: { id: payment.id }
          }, {
            onSuccess: () => setSuccess(true)
          });
        }, 1000);
      }
    });
  };

  return (
    <div className="min-h-screen py-24 px-6 max-w-3xl mx-auto">
      <h1 className="text-4xl font-black mb-8 uppercase text-center">Checkout</h1>
      
      <div className="bg-card border border-border rounded-xl p-8 mb-8">
        <h2 className="text-xl font-bold mb-4 uppercase text-muted-foreground border-b border-border pb-4">Booking Summary</h2>
        <div className="flex justify-between items-center mb-4">
          <span className="text-lg">{booking.trip?.title}</span>
        </div>
        <div className="text-sm text-muted-foreground">For {booking.numberOfPeople} people</div>
      </div>

      <div className="bg-card border border-border rounded-xl p-8">
        <h2 className="text-xl font-bold mb-6 uppercase text-muted-foreground">Payment Method</h2>
        
        <div className="flex gap-4 mb-8">
          {["UPI", "CARD", "NET BANKING"].map((m) => (
            <button
              key={m}
              onClick={() => setMethod(m)}
              className={`flex-1 py-4 border rounded-md font-bold transition-colors ${method === m ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-muted-foreground'}`}
            >
              {m}
            </button>
          ))}
        </div>

        <Button 
          onClick={handlePay} 
          disabled={initiatePayment.isPending || confirmPayment.isPending}
          className="w-full h-16 text-xl font-black uppercase tracking-widest"
        >
          {initiatePayment.isPending || confirmPayment.isPending ? 'Processing...' : 'Confirm Payment'}
        </Button>
      </div>
    </div>
  );
}
