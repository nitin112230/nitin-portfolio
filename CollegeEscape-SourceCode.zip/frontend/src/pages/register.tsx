import { useRegister } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Register() {
  const register = useRegister();
  const { setToken } = useAuth();
  const [, setLocation] = useLocation();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    college: "",
    phone: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    register.mutate({
      data: formData
    }, {
      onSuccess: (res) => {
        setToken(res.token);
        setLocation("/trips");
      }
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative py-20">
      <div className="w-full max-w-md bg-card border border-border p-8 rounded-2xl relative z-10">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-black mb-2 uppercase text-primary">Join the club</h1>
          <p className="text-muted-foreground font-sans">Your next adventure starts here.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-bold mb-2 uppercase text-muted-foreground">Name</label>
            <input 
              type="text" required
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="block text-sm font-bold mb-2 uppercase text-muted-foreground">Email</label>
            <input 
              type="email" required
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="block text-sm font-bold mb-2 uppercase text-muted-foreground">Password</label>
            <input 
              type="password" required
              value={formData.password}
              onChange={e => setFormData({...formData, password: e.target.value})}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="block text-sm font-bold mb-2 uppercase text-muted-foreground">College</label>
            <input 
              type="text" required
              value={formData.college}
              onChange={e => setFormData({...formData, college: e.target.value})}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="block text-sm font-bold mb-2 uppercase text-muted-foreground">Phone</label>
            <input 
              type="tel"
              value={formData.phone}
              onChange={e => setFormData({...formData, phone: e.target.value})}
              className="w-full bg-input border border-border rounded-md px-4 py-3 font-sans focus:outline-none focus:border-primary"
            />
          </div>
          
          <Button 
            type="submit" 
            disabled={register.isPending}
            className="w-full h-14 text-lg font-bold uppercase tracking-wider mt-4"
          >
            {register.isPending ? 'Creating Account...' : 'Sign Up'}
          </Button>
        </form>

        <div className="mt-8 text-center text-sm font-sans text-muted-foreground">
          Already verified? <Link href="/login" className="text-secondary hover:underline">Log in</Link>
        </div>
      </div>
    </div>
  );
}
