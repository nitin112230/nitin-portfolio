import { useGetTripStats, useGetFeaturedTrips } from "@workspace/api-client-react";
import { Link } from "wouter";
import { useEffect, useRef, useState } from "react";
import { useCurrency } from "@/lib/currency";

const TRUST_BADGES = [
  { icon: "🛡️", title: "100% Safe & Verified Trips", color: "#FF2D9B" },
  { icon: "⭐", title: "4.9/5 Rating — 500+ Happy Travelers", color: "#FFD700" },
  { icon: "💳", title: "Secure International Payments", color: "#00D4FF" },
  { icon: "📞", title: "24/7 Support on WhatsApp", color: "#25D366" },
  { icon: "✈️", title: "India's #1 College Travel Brand", color: "#FF2D9B" },
];

const TESTIMONIALS = [
  { name: "Rahul S.", city: "Delhi", flag: "🇮🇳", stars: 5, text: "Goa trip was INSANE! Best 4 days of my college life. Everything was perfectly organized." },
  { name: "Priya M.", city: "Mumbai", flag: "🇮🇳", stars: 5, text: "Booked Bali package, they handled everything. Zero stress, 100% memories!" },
  { name: "Arjun K.", city: "Bangalore", flag: "🇮🇳", stars: 5, text: "Manali trip with 28 friends — CollegeEscape made it look easy. Already booked Kasol next!" },
  { name: "Sarah T.", city: "UK", flag: "🇬🇧", stars: 5, text: "Found this while studying in India. Joined the Goa trip, met amazing people. 10/10!" },
  { name: "Ahmed R.", city: "UAE", flag: "🇦🇪", stars: 5, text: "Dubai escape package was worth every dirham. Highly recommend to NRI students!" },
  { name: "Zara L.", city: "Singapore", flag: "🇸🇬", stars: 5, text: "Bangkok trip with CollegeEscape — unreal experience. Booking Bali next month!" },
];

function getBadgeInfo(title: string) {
  const t = title.toLowerCase();
  if (t.includes("goa")) return { text: "MOST POPULAR", color: "from-pink-500 to-orange-400" };
  if (t.includes("manali")) return { text: "NEW", color: "from-cyan-400 to-blue-500" };
  if (t.includes("kasol") || t.includes("rishikesh")) return { text: "ADVENTURE", color: "from-green-400 to-emerald-600" };
  if (t.includes("pondicherry") || t.includes("puducherry")) return { text: "CHILL", color: "from-sky-400 to-cyan-500" };
  if (t.includes("coorg")) return { text: "NATURE", color: "from-lime-400 to-green-600" };
  if (t.includes("rajasthan")) return { text: "PREMIUM", color: "from-yellow-400 to-orange-500" };
  if (t.includes("bangkok") || t.includes("bali") || t.includes("dubai")) return { text: "INTERNATIONAL", color: "from-yellow-400 to-amber-500" };
  return { text: "HOT", color: "from-pink-500 to-purple-600" };
}

export default function Home() {
  const { data: stats } = useGetTripStats();
  const { data: trips } = useGetFeaturedTrips();
  const { format } = useCurrency();
  const carouselRef = useRef<HTMLDivElement>(null);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused) return;
    const el = carouselRef.current;
    if (!el) return;
    const id = setInterval(() => {
      el.scrollBy({ left: 320, behavior: "smooth" });
      if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 10) {
        el.scrollTo({ left: 0, behavior: "smooth" });
      }
    }, 3000);
    return () => clearInterval(id);
  }, [paused]);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative py-32 px-6 overflow-hidden flex items-center justify-center min-h-[80vh]">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background z-10" />
        </div>
        <div className="relative z-10 text-center max-w-4xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-black mb-6 tracking-tight">
            YOUR ESCAPE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF2D9B] via-white to-[#00D4FF]">AWAITS</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-2xl mx-auto font-sans">
            Curated party trips, epic memories, zero planning stress. The definitive college travel experience.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/trips"
              className="inline-flex items-center justify-center h-12 px-8 rounded-md font-black uppercase tracking-wider text-white transition-all hover:shadow-[0_0_25px_#FF2D9B88]"
              style={{ background: "linear-gradient(90deg,#FF2D9B,#00D4FF)" }}>
              EXPLORE TRIPS
            </Link>
            <a href="https://wa.me/919599896274" target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 h-12 px-8 rounded-md font-bold uppercase tracking-wider border border-[#25D366]/50 text-[#25D366] hover:bg-[#25D366]/10 transition-colors">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-[#25D366]"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              WhatsApp Us
            </a>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-6 px-6 border-y border-white/10 overflow-hidden">
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide max-w-7xl mx-auto">
          {TRUST_BADGES.map((b, i) => (
            <div key={i} className="shrink-0 flex items-center gap-3 bg-white/5 backdrop-blur border border-white/10 rounded-xl px-5 py-3 hover:border-white/20 transition-colors"
              style={{ boxShadow: `0 0 12px ${b.color}22` }}>
              <span className="text-2xl" style={{ filter: `drop-shadow(0 0 6px ${b.color})` }}>{b.icon}</span>
              <span className="text-sm font-bold text-muted-foreground whitespace-nowrap">{b.title}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Stats */}
      {stats && (
        <section className="py-16 px-6 bg-card/30">
          <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { val: `${stats.totalTrips}+`, label: "Epic Trips", color: "text-[#FF2D9B]" },
              { val: `${stats.totalStudents}+`, label: "Students", color: "text-[#00D4FF]" },
              { val: stats.citiesCovered, label: "Cities", color: "text-[#FFD700]" },
              { val: `${stats.avgRating}/5`, label: "Avg Rating", color: "text-[#FF2D9B]" },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className={`text-4xl font-black mb-2 ${s.color}`}>{s.val}</div>
                <div className="text-sm text-muted-foreground uppercase tracking-wider">{s.label}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Featured Trips */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-4xl font-black mb-3 bg-gradient-to-r from-[#FF2D9B] to-[#00D4FF] bg-clip-text text-transparent uppercase">TRENDING NOW</h2>
            <p className="text-muted-foreground text-lg">The most hyped drops this season.</p>
          </div>
          <Link href="/trips" className="text-primary hover:text-primary/80 font-bold uppercase tracking-wider hidden md:block">
            View All →
          </Link>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {trips?.map((trip) => {
            const badge = getBadgeInfo(trip.title);
            const isIntl = ["thailand", "indonesia", "uae", "dubai", "bali", "bangkok"].some(k => trip.destination.toLowerCase().includes(k));
            return (
              <Link key={trip.id} href={`/trips/${trip.id}`} className="group block">
                <div className="rounded-2xl overflow-hidden border transition-all duration-300 group-hover:scale-[1.02]"
                  style={{
                    background: "linear-gradient(135deg,rgba(255,45,155,0.05),rgba(10,0,20,0.95),rgba(0,212,255,0.05))",
                    borderColor: isIntl ? "rgba(255,215,0,0.25)" : "rgba(255,45,155,0.2)",
                  }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = isIntl ? "0 0 30px rgba(255,215,0,0.3)" : "0 0 30px rgba(255,45,155,0.25)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}>
                  <div className="aspect-[4/3] relative overflow-hidden">
                    {trip.imageUrl && <img src={trip.imageUrl} alt={trip.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0a0010] via-[#0a0010]/30 to-transparent" />
                    <div className={`absolute top-4 right-4 bg-gradient-to-r ${badge.color} text-white text-xs font-black px-3 py-1 rounded-full uppercase`}>{badge.text}</div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-black uppercase mb-1 group-hover:text-[#FF2D9B] transition-colors">{trip.title}</h3>
                    <div className="text-muted-foreground text-sm mb-3 font-sans">{trip.duration}</div>
                    {trip.price > 0 && (
                      <div className="text-lg font-black bg-gradient-to-r from-[#FF2D9B] to-[#00D4FF] bg-clip-text text-transparent mb-3">
                        {format(trip.price)}<span className="text-xs text-muted-foreground ml-1" style={{ WebkitTextFillColor: "unset" }}>/person</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">{new Date(trip.departureDate).toLocaleDateString()}</span>
                      <span className="text-[#00D4FF] font-bold">{trip.availableSeats} seats left</span>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-6 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-black text-center mb-3 uppercase bg-gradient-to-r from-[#FF2D9B] to-[#00D4FF] bg-clip-text text-transparent">What They Say</h2>
          <p className="text-center text-muted-foreground mb-12 font-sans">Real stories from real travelers.</p>
          <div
            ref={carouselRef}
            className="flex gap-6 overflow-x-auto pb-4 scroll-smooth"
            style={{ scrollbarWidth: "none" }}
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
          >
            {[...TESTIMONIALS, ...TESTIMONIALS].map((t, i) => (
              <div key={i} className="shrink-0 w-72 rounded-2xl p-6 border border-white/10 bg-white/5 backdrop-blur hover:border-[#FF2D9B]/40 transition-colors"
                style={{ boxShadow: "0 0 20px rgba(255,45,155,0.05)" }}>
                <div className="text-[#FFD700] text-lg mb-3">{"★".repeat(t.stars)}</div>
                <p className="text-sm text-muted-foreground font-sans leading-relaxed mb-4">"{t.text}"</p>
                <div className="flex items-center gap-2">
                  <span className="text-xl">{t.flag}</span>
                  <div>
                    <div className="font-bold text-sm">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.city}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
