import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth";
import { CurrencyProvider } from "@/lib/currency";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import WhatsAppButton from "@/components/whatsapp-button";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Trips from "@/pages/trips";
import TripDetail from "@/pages/trip-detail";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Payment from "@/pages/payment";
import MyTrips from "@/pages/my-trips";
import Admin from "@/pages/admin";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/trips" component={Trips} />
      <Route path="/trips/:id" component={TripDetail} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/payment/:bookingId" component={Payment} />
      <Route path="/my-trips" component={MyTrips} />
      <Route path="/admin" component={Admin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <CurrencyProvider>
        <AuthProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Navbar />
              <div className="pt-16">
                <Router />
                <Footer />
              </div>
              <WhatsAppButton />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </CurrencyProvider>
    </QueryClientProvider>
  );
}

export default App;
