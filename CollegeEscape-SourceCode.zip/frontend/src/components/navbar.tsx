import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useCurrency, CURRENCIES, CurrencyCode } from "@/lib/currency";
import { useState } from "react";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [currencyOpen, setCurrencyOpen] = useState(false);

  const handleLogout = () => { logout(); setMenuOpen(false); };
  const cur = CURRENCIES.find(c => c.code === currency)!;

  const navLink = (href: string, label: string) => (
    <Link href={href} onClick={() => setMenuOpen(false)}
      className={`font-bold uppercase tracking-wider text-sm transition-colors hover:text-primary ${location === href ? "text-primary" : "text-muted-foreground"}`}>
      {label}
    </Link>
  );

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="text-xl font-black uppercase tracking-tight hover:text-primary transition-colors shrink-0">
          College<span className="text-primary">Escape</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-6">
          {navLink("/", "Home")}
          {navLink("/trips", "Trips")}
          {user && navLink("/my-trips", "My Trips")}
        </div>

        {/* Right side */}
        <div className="hidden md:flex items-center gap-3">
          {/* Currency Selector */}
          <div className="relative">
            <button
              onClick={() => setCurrencyOpen(!currencyOpen)}
              className="flex items-center gap-1.5 bg-white/5 border border-white/15 hover:border-[#FF2D9B]/50 rounded-full px-3 py-1.5 text-sm font-bold transition-colors"
            >
              <span>{cur.flag}</span>
              <span className="text-muted-foreground">{cur.code}</span>
              <span className="text-muted-foreground text-xs">▾</span>
            </button>
            {currencyOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setCurrencyOpen(false)} />
                <div className="absolute right-0 top-full mt-2 z-20 bg-[#0a0010]/95 backdrop-blur-xl border border-white/15 rounded-xl overflow-hidden shadow-[0_0_30px_#FF2D9B22] min-w-[160px]">
                  {CURRENCIES.map(c => (
                    <button key={c.code} onClick={() => { setCurrency(c.code as CurrencyCode); setCurrencyOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm font-bold hover:bg-white/5 transition-colors text-left ${currency === c.code ? "text-[#FF2D9B]" : "text-muted-foreground"}`}>
                      <span>{c.flag}</span>
                      <span>{c.code}</span>
                      <span className="ml-auto text-xs opacity-60">{c.symbol}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Auth */}
          {user ? (
            <>
              <span className="text-sm text-muted-foreground font-sans">
                Hey, <span className="text-foreground font-bold">{user.name.split(" ")[0]}</span>
              </span>
              <button onClick={handleLogout} className="text-sm font-bold uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-bold uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors">Login</Link>
              <Link href="/register" className="bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-bold uppercase tracking-wider hover:bg-primary/90 transition-colors">
                Sign Up
              </Link>
            </>
          )}
        </div>

        {/* Mobile: currency + hamburger */}
        <div className="flex md:hidden items-center gap-2">
          <button onClick={() => setCurrencyOpen(!currencyOpen)}
            className="flex items-center gap-1 bg-white/5 border border-white/15 rounded-full px-2.5 py-1 text-xs font-bold">
            <span>{cur.flag}</span><span className="text-muted-foreground">{cur.code}</span>
          </button>
          {currencyOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setCurrencyOpen(false)} />
              <div className="absolute right-16 top-16 z-20 bg-[#0a0010]/95 backdrop-blur-xl border border-white/15 rounded-xl overflow-hidden shadow-[0_0_30px_#FF2D9B22] min-w-[140px]">
                {CURRENCIES.map(c => (
                  <button key={c.code} onClick={() => { setCurrency(c.code as CurrencyCode); setCurrencyOpen(false); }}
                    className={`w-full flex items-center gap-2 px-3 py-2 text-xs font-bold hover:bg-white/5 transition-colors text-left ${currency === c.code ? "text-[#FF2D9B]" : "text-muted-foreground"}`}>
                    <span>{c.flag}</span><span>{c.code}</span>
                  </button>
                ))}
              </div>
            </>
          )}
          <button className="flex flex-col gap-1.5 p-2" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            <span className={`block w-6 h-0.5 bg-foreground transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
            <span className={`block w-6 h-0.5 bg-foreground transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
            <span className={`block w-6 h-0.5 bg-foreground transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-background border-t border-border px-6 py-6 flex flex-col gap-6">
          {navLink("/", "Home")}
          {navLink("/trips", "Trips")}
          {user && navLink("/my-trips", "My Trips")}
          <div className="border-t border-border pt-6 flex flex-col gap-4">
            {user ? (
              <>
                <span className="text-sm text-muted-foreground font-sans">Logged in as <span className="text-foreground font-bold">{user.name}</span></span>
                <button onClick={handleLogout} className="text-left text-sm font-bold uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors">Logout</button>
              </>
            ) : (
              <>
                <Link href="/login" onClick={() => setMenuOpen(false)} className="text-sm font-bold uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors">Login</Link>
                <Link href="/register" onClick={() => setMenuOpen(false)} className="bg-primary text-primary-foreground px-5 py-3 rounded-md text-sm font-bold uppercase tracking-wider text-center hover:bg-primary/90 transition-colors">Sign Up Free</Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
