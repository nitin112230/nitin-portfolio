export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black/40 backdrop-blur-md mt-24">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="text-2xl font-black uppercase mb-3">
              College<span className="text-[#FF2D9B]">Escape</span>
            </div>
            <p className="text-muted-foreground text-sm font-sans leading-relaxed mb-4">
              India's #1 college travel brand. Curated party trips for students across India and beyond.
            </p>
            <div className="text-sm text-muted-foreground font-sans">
              Serving travelers from{" "}
              <span className="text-foreground">🇮🇳 India &nbsp;|&nbsp; 🇦🇪 UAE &nbsp;|&nbsp; 🇬🇧 UK &nbsp;|&nbsp; 🇸🇬 Singapore &nbsp;|&nbsp; 🇦🇺 Australia</span>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-black uppercase text-sm tracking-wider mb-4 text-foreground">Quick Links</h4>
            <div className="flex flex-col gap-3">
              {[
                { href: "/trips", label: "All Trips" },
                { href: "/register", label: "Sign Up" },
                { href: "/login", label: "Login" },
                { href: "/my-trips", label: "My Bookings" },
              ].map(l => (
                <a key={l.href} href={l.href} className="text-sm text-muted-foreground hover:text-[#FF2D9B] transition-colors font-sans">{l.label}</a>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-black uppercase text-sm tracking-wider mb-4 text-foreground">Contact</h4>
            <div className="flex flex-col gap-3 text-sm text-muted-foreground font-sans">
              <a href="mailto:contact@collegeescape.com" className="hover:text-[#FF2D9B] transition-colors">
                contact@collegeescape.com
              </a>
              <a href="https://wa.me/919599896274" target="_blank" rel="noopener noreferrer" className="hover:text-[#25D366] transition-colors flex items-center gap-2">
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-[#25D366]"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                +91 9599896274
              </a>
              {/* Socials */}
              <div className="flex gap-4 pt-2">
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-muted-foreground hover:border-[#FF2D9B] hover:text-[#FF2D9B] transition-colors text-sm font-bold">
                  IG
                </a>
                <a href="https://youtube.com" target="_blank" rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-muted-foreground hover:border-red-500 hover:text-red-500 transition-colors text-xs font-bold">
                  YT
                </a>
                <a href="https://wa.me/919599896274" target="_blank" rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-muted-foreground hover:border-[#25D366] hover:text-[#25D366] transition-colors text-xs font-bold">
                  WA
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground font-sans">
          <span>© 2025 CollegeEscape. All rights reserved.</span>
          <div className="flex gap-6">
            <a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-foreground transition-colors">Refund Policy</a>
            <a href="#" className="hover:text-foreground transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
